#!/usr/bin/env python3
#  Copyright (C) 2021
#      Max Planck Institute for Polymer Research & JGU Mainz
#  This file is part of ESPResSo++.
#
#  ESPResSo++ is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  ESPResSo++ is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.

###########################################################################
#                                                                         #
#  ESPResSo++ Python script for a Lennard-Jones System including          #
#  runtime details
#                                                                         #
###########################################################################

import time
import espressopp
import argparse
import numpy as np
import sys
from mpi4py import MPI

import espp_run_utils.utils as ut
import espp_run_utils.lennard_jones_prep as lj_prep

######################################################################
print(espressopp.Version().info())
print('Setting up simulation ...\n')

######################################################################
### Parse arguments
parser = argparse.ArgumentParser()

# simulation type
parser.add_argument("--simulation", type=str, choices={"lj", "pm"}, required=True)

# execution parameters
parser.add_argument("--runType", type=str, choices={"orig", "soa", "vec"}, required=True)

# output parameters
parser.add_argument("--outBase", type=str, required=True)
parser.add_argument("--trial", type=int, default=0, required=True)

args, _ = parser.parse_known_args()

ut.print_arguments(args)
######################################################################

######################################################################
### output filenames
props_sim = {
    "sim":args.simulation,
}
props_base = {
    "rt":args.runType,
    "nr":MPI.COMM_WORLD.Get_size(),
    "tr":args.trial,
}
out_file = {
    "time":ut.generate_filename(args.outBase, {**props_sim, "data":"t", **props_base}, "pkl"),
    "verlet_list":ut.generate_filename(args.outBase, {**props_sim, "data":"vl", **props_base}, "pkl")
}

ut.print_output_names(out_file)
######################################################################

######################################################################
### general parameters
nsteps      = 1000
timestep    = 0.005
temperature = 1.0
replicate   = (2,2,2)

######################################################################
### simulation-specific parameters
if args.simulation == "lj":
    print("Running Lennard-Jones simulation")

    rc          = 2.5
    skin        = 0.3

elif args.simulation == "pm":
    print("Running polymer melt simulation")

    rc          = pow(2.0, 1.0/6.0)
    skin        = 0.4

else:
    raise ValueError(f"Invalid args.simulation={args.simulation}")

######################################################################
### setup simulation

T = ut.Timer("Reading input particles")
if args.simulation == "lj":
    x, y, z, Lx, Ly, Lz = lj_prep.generate_positions(32)
    bonds = angles = []
elif args.simulation == "pm":
    bonds, angles, x, y, z, Lx, Ly, Lz = espressopp.tools.lammps.read('polymer_melt.lammps')
T.end()

T = ut.Timer("Replicating particles")
bonds, angles, x, y, z, Lx, Ly, Lz = espressopp.tools.replicate(bonds, angles, x, y, z, Lx, Ly, Lz, *replicate)
T.end()

num_particles = len(x)
density = num_particles / (Lx * Ly * Lz)
box = (Lx, Ly, Lz)

use_vec = (args.runType == "soa" or args.runType == "vec")
if use_vec:
    system, integrator = espressopp.vec.standard_system.Default(box=box, rc=rc, skin=skin, dt=timestep, temperature=temperature)
else:
    system, integrator = espressopp.standard_system.Default(box=box, rc=rc, skin=skin, dt=timestep, temperature=temperature)

print("")

T = ut.Timer("Adding particles")
properties = ['id', 'type', 'mass', 'posx', 'posy', 'posz']
ids = np.arange(1, num_particles+1)
types = np.zeros(num_particles)
mass = np.ones(num_particles)
particles = np.stack((ids, types, mass, x, y, z), axis=-1)
system.storage.addParticlesArray(particles, *properties)
T.end()

T = ut.Timer("Decompose")
system.storage.decompose()
T.end()

if use_vec:
    # Lennard-Jones with Verlet list
    vl      = espressopp.vec.VerletList(system, cutoff = rc)
    potLJ   = espressopp.vec.interaction.LennardJones(epsilon=1.0, sigma=1.0, cutoff=rc, shift=0)
    interLJ = espressopp.vec.interaction.VerletListLennardJones(vl)
    interLJ.setPotential(type1=0, type2=0, potential=potLJ)
    system.addInteraction(interLJ)

    if args.simulation == "pm":
        # FENE bonds
        fpl       = espressopp.vec.FixedPairList(system.storage)
        fpl.addBonds(bonds)
        potFENE   = espressopp.vec.interaction.FENE(K=30.0, r0=0.0, rMax=1.5)
        interFENE = espressopp.vec.interaction.FixedPairListFENE(system, fpl, potFENE)
        system.addInteraction(interFENE)

        # Cosine with FixedTriple list
        ftl         = espressopp.vec.FixedTripleList(system.storage)
        ftl.addTriples(angles)
        potCosine   = espressopp.vec.interaction.Cosine(K=1.5, theta0=3.1415926)
        interCosine = espressopp.vec.interaction.FixedTripleListCosine(system, ftl, potCosine)
        system.addInteraction(interCosine)
else:
    # Lennard-Jones with Verlet list
    vl      = espressopp.VerletList(system, cutoff = rc, useBuffers=False)
    potLJ   = espressopp.interaction.LennardJones(epsilon=1.0, sigma=1.0, cutoff=rc, shift=0)
    interLJ = espressopp.interaction.VerletListLennardJones(vl)
    interLJ.setPotential(type1=0, type2=0, potential=potLJ)
    system.addInteraction(interLJ)

    if args.simulation == "pm":
        # FENE bonds
        fpl       = espressopp.FixedPairList(system.storage)
        fpl.addBonds(bonds)
        potFENE   = espressopp.interaction.FENE(K=30.0, r0=0.0, rMax=1.5)
        interFENE = espressopp.interaction.FixedPairListFENE(system, fpl, potFENE)
        system.addInteraction(interFENE)

        # Cosine with FixedTriple list
        ftl         = espressopp.FixedTripleList(system.storage)
        ftl.addTriples(angles)
        potCosine   = espressopp.interaction.Cosine(K=1.5, theta0=3.1415926)
        interCosine = espressopp.interaction.FixedTripleListCosine(system, ftl, potCosine)
        system.addInteraction(interCosine)

# print simulation parameters
print('')
print('number of particles = ', num_particles)
print('box                 = ', box)
print('density             = ', density)
print('rc                  = ', rc)
print('dt                  = ', integrator.dt)
print('skin                = ', system.skin)
print('temperature         = ', temperature)
print('nsteps              = ', nsteps)
print('NodeGrid            = ', system.storage.getNodeGrid())
print('CellGrid            = ', system.storage.getCellGrid())
print('')

######################################################################
### run simulation

vl.resetTimers()
espressopp.tools.analyse.info(system, integrator)

start_time = time.process_time()
integrator.run(nsteps)
espressopp.tools.analyse.info(system, integrator)
end_time = time.process_time()

espressopp.tools.analyse.final_info(system, integrator, vl, start_time, end_time)

######################################################################
### export timers

def calc_timers(alltimers, labels):
    t = []
    nprocs = len(alltimers)
    for ntimer in range(len(labels)):
        t.append(0.0)
        for k in range(nprocs):
            t[ntimer] += alltimers[k][ntimer]
        t[ntimer] /= nprocs
    return t

def show_timers(alltimers, labels, precision=3):
    import sys
    fmt1 = '%.' + str(precision) + 'f\n'
    fmt2 = '%.' + str(precision) + 'f (%.' + str(precision) + 'f)\n'
    t = calc_timers(alltimers, labels)
    for i,label in enumerate(labels):
        sys.stdout.write('{:20} time = '.format(label) + fmt1 % t[i])

def save_timers(filename, runType, alltimers, labels, precision=3, show_df=False):
    import pandas as pd
    t = calc_timers(alltimers, labels)
    df = pd.DataFrame(data=t,index=labels, columns=[runType])
    if show_df: print(df)
    print("Saving to", filename)
    df.to_pickle(filename)

labels = ["Run","Pair","FENE","Angle","Comm1","Comm2","Int1","Int2","Resort","Other","Rebuild"]
alltimers = [a+b  for a,b in zip(integrator.getTimers(), vl.getTimers())]

assert args.runType is not None
save_timers(out_file["time"], args.runType, alltimers, labels)
