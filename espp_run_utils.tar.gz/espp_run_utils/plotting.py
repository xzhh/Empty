import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from . import utils as ut
from . import meta as meta

MACHINE_NAMES = {
    "mogon" : "Mogon (Intel Skylake)",
    "raven" : "Raven (Intel Icelake)",
    "amd" : "AMD EPYC Rome"
}

def plot_format(title, xlabel=None, ylabel=None, ylim_zero=True, legend=True, tight_layout=True):
    if ylim_zero: plt.ylim(0,)

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)

    if legend: plt.legend(loc=0)
    if tight_layout: plt.tight_layout()

def fig_save(fig, filenames, *args, **kwargs):
    import warnings
    warnings.filterwarnings("ignore", message="Attempted to set non-positive left xlim on a "
                            "log-scaled axis.\nInvalid limit will be ignored.")
    if not ut.iterable(filenames):
        filenames = [filenames]
    for filename in filenames:
        plt.tight_layout()
        fig.savefig(filename, *args, **kwargs)
        print(f"Saved plot: {filename}")
    fig.clf()

def plot_save(filenames, *args, **kwargs):
    fig_save(plt, filenames, *args, **kwargs) # or use plt.gcf()?
    plt.clf()
    plt.close('all')

def plot_format_save(filenames, *args, **kwargs):
    plot_format(*args, **kwargs)
    plot_save(filenames)

def scalar_formatter(ax):
    from matplotlib.ticker import ScalarFormatter
    for axis in [ax.xaxis, ax.yaxis]:
        axis.set_major_formatter(ScalarFormatter())

def integer_formatter(ax, x=False, y=False):
    from matplotlib.ticker import FormatStrFormatter
    if x: ax.xaxis.set_major_formatter(FormatStrFormatter('%d'))
    if y: ax.yaxis.set_major_formatter(FormatStrFormatter('%d'))

def sns_reset():
    sns.set_theme()
    sns.set_style("whitegrid")

def ax_legend_outside_box(ax, step=1, **kwargs):
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles[::step], labels[::step], bbox_to_anchor=(1.0, 1.0), loc="upper left", **kwargs)
    return ax

def ax_set_rotation(ax, rotation, **kwargs):
    ax.set_xticklabels(ax.get_xticklabels(), rotation = rotation, **kwargs)
    return ax

###################################################################################################
## functions for eval_02_hpx4espp
##

def plot_ns_tuning(parsed, title, filename_prefix, print_info=False, **process_time_kwargs):
    RUN_TIME = "elapsed time (s)"
    NUM_SUB = r"$n_\operatorname{sub}$ per core"
    NUM_SUB_SHORT = "num. subd."
    SECTION = "section"

    MPI_COLOR = "grey"

    filename_base = ut.generate_filename_replace_props(parsed[0], {"ns":"ZZ","tr":"ZZ"})

    rts = ["hpx_off", "hpx_on"]
    i_hpx_off = rts.index("hpx_off")
    i_hpx_on = rts.index("hpx_on")

    filtered = ut.filter_property(parsed, "data", "t")
    filtered_trials, trials = ut.split_by_trials(filtered)

    df_runs_stats = {rt:[] for rt in rts}
    df_secs_stats = {rt:[] for rt in rts}
    for ft, t in zip(filtered_trials, trials):
        df_runs, df_secs = ut.process_time_df_rts_key(ft, rts, "ns", lj=True, **process_time_kwargs)

        for i,rt in enumerate(rts):
            df_runs_stats[rt].append(df_runs[i])
            df_secs_stats[rt].append(df_secs[i])

    for rt in rts:
        df_runs_stats[rt] = ut.get_trial_stats(df_runs_stats[rt])
        df_secs_stats[rt] = ut.get_trial_stats(df_secs_stats[rt])

    df_runs = [df_runs_stats[rt]["mean"] for rt in rts]
    df_secs = [df_secs_stats[rt]["mean"] for rt in rts]

    cores_per_socket = meta.get_meta_from_cwd()["cores_per_socket"]
    def as_nsub_per_core(nsub):
        assert nsub % cores_per_socket == 0
        return nsub // cores_per_socket

    df_runs[i_hpx_on] = df_runs[i_hpx_on].rename(index=as_nsub_per_core)
    df_secs[i_hpx_on] = df_secs[i_hpx_on].rename(index=as_nsub_per_core)

    HPX_COLORS = sns.color_palette("magma", n_colors=len(df_runs[i_hpx_on]))
    MPI_HPX_COLORS = [MPI_COLOR]+HPX_COLORS

    ###########################################################
    # tuning of total runtime based on ns
    df_runs[i_hpx_off] = df_runs[i_hpx_off].rename(index={1:"(mpi)"})
    df_runs_hpx_off = df_runs[i_hpx_off].copy()
    df_runs = pd.concat(df_runs, axis=0)

    sns_reset()

    fig, (ax0, ax1) = plt.subplots(nrows=2, gridspec_kw={'height_ratios': [1,1.4]})
    ax0 = df_runs.squeeze().plot.bar(ax=ax0, label='hpx', title=title, xlabel=NUM_SUB, ylabel=RUN_TIME, color=MPI_HPX_COLORS)
    ax0 = ax_set_rotation(ax0, 0)

    t_hpx_off = df_runs_hpx_off.values[0]
    ax0.axhline(y=t_hpx_off, color=MPI_COLOR, linestyle='-.', zorder=0)

    ###########################################################
    # tuning of sectional times based on ns
    df_secs[i_hpx_off] = df_secs[i_hpx_off].rename(index={1:"(mpi)"})
    df_secs = pd.concat(df_secs, axis=0)

    df_secs.transpose().plot.bar(ax=ax1, xlabel=SECTION, ylabel=RUN_TIME, color=MPI_HPX_COLORS)
    ax1 = ax_set_rotation(ax1, 0)
    ax1.get_legend().remove()

    fig.tight_layout()
    fig_save(fig, [filename_base + "-ns-tuning.pdf", filename_prefix + ".pdf"])

    if print_info:
        df_runs_t  = df_runs.drop('(mpi)')
        df_runs_sp = t_hpx_off / df_runs_t
        df_runs_t_sp = pd.concat([df_runs_t, df_runs_sp], axis=1, keys=["time", "speedup"])
        ut.print_variable("idxmax", df_runs_sp.idxmax(), 12)
        ut.print_variable("max", df_runs_sp.max(), 12)
        ut.print_variable("t_hpx_off",t_hpx_off, 12)
        ut.pprint_variable("df_runs_t_sp", df_runs_t_sp, None)

###################################################################################################
