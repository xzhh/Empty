import argparse
import os
import time
import numpy as np
import pandas as pd
import copy
import collections
import six
from pathlib import Path
from pprint import pprint

class Timer:
    def __init__(self, msg, print_msg=True, obey_quiet=False):
        if obey_quiet:
            parser = argparse.ArgumentParser()
            parser.add_argument("--quiet", nargs='?', type=bool, const=True, default=False)
            args, unknown_args = parser.parse_known_args()
            self.quiet = args.quiet
        else:
            self.quiet = False

        self.time_start = time.time()
        self.msg = msg
        if print_msg and not self.quiet: print("\n{}...".format(self.msg), flush=True)

    def end(self, print_msg=True, post_msg="DONE"):
        if print_msg and not self.quiet: print("{}... {} {} s\n".format(self.msg, post_msg, time.time()-self.time_start), flush=True)

def print_variable(name, var, space=30, obey_quiet=False, use_pprint=False):
    if obey_quiet:
        parser = argparse.ArgumentParser()
        parser.add_argument("--quiet", nargs='?', type=bool, const=True, default=False)
        args, unknown_args = parser.parse_known_args()
        if args.quiet:
            return
    if space is None:
        space = ""
    fmt = "{:<"+str(space)+"} ="
    if use_pprint:
        print(fmt.format(name), flush=True)
        pprint(var)
        print("", flush=True)
    else:
        print(fmt.format(name), var, flush=True)

def pprint_variable(*args, **kwargs):
    print_variable(*args, **kwargs, use_pprint=True)

printv = print_variable
pprintv = pprint_variable

def generate_filename(filename_base, props, extension):
    props_string = "-".join([ p+"="+str(props[p]) for p in props ])
    return filename_base + "---" + props_string + "." + extension

def generate_filename_replace_props(parsed_entry, props_map):
    filename, base, props, extension = copy.deepcopy(parsed_entry)
    for key in props_map:
        props[key] = props_map[key]
    return generate_filename(base, props, extension)

def iterable(arg):
    return (
        isinstance(arg, collections.Iterable)
        and not isinstance(arg, six.string_types)
    )

##################################################################################################
### Parsing Output Files

def removesuffix(stem, suffix):
    if hasattr(stem, 'removesuffix'):
        # for Python >= 3.9
        return stem.removesuffix(suffix)
    else:
        if stem.endswith(suffix):
            return stem[:-len(suffix)]

def parse_filename(f):
    base, stem = f.split("---")
    extension = stem.split(".")[-1]
    # props_string = stem.removesuffix("." + extension)
    props_string = removesuffix(stem, "." + extension)
    props_split = props_string.split("-")
    props_split = [prop.split("=") for prop in props_split]
    props = {key:value for key,value in props_split}
    return base, props, extension

def read_base(args):
    if args.base is None:
        ls = os.listdir()
        ls = [l for l in ls if l.endswith('.pkl') or l.endswith('.npy')]
        ls = [l.split("---") for l in ls]
        ls = sorted(ls, key=lambda l: l[0])
        if len(ls) == 0:
            raise RuntimeError("Could not find suitable pkl or npy files")
        last = ls[-1]
        base = last[0]
    else:
        base = args.base
    return base

def get_filename_base():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=str, default=None)
    args, _ = parser.parse_known_args()

    base = read_base(args)
    print("base:", base, flush=True)

    return base

def get_files_from_base(base):
    ls = os.listdir()
    ls = [l for l in ls if l.startswith(base) and (l.endswith('.pkl') or l.endswith('.npy'))]
    ls = sorted(ls)
    return ls

def parse_files(files):
    # output list of (0:filename, 1:base, 2:props, 3:extension)
    return [(f, *parse_filename(f)) for f in files]

def check_same_base(parsed):
    bases = [p[1] for p in parsed]
    if len(bases) > 0:
        return bases.count(bases[0]) == len(bases)
    else:
        return True

def filter_property(parsed, key, value):
    return [p for p in parsed if p[2][key]==value]

def filter_property_operator(parsed, operator, key, value):
    return [p for p in parsed if operator(type(value)(p[2][key]), value)]

def sort_by_property(parsed, key, dtype=int):
    ''' sort by integer key '''
    parsed = sorted(parsed, key=lambda x: dtype(x[2][key]))
    keys = [dtype(r[2][key]) for r in parsed]
    assert len(keys) == len(set(keys)), "Some elements are not unique: key={} keys={}".format(key, keys)
    return parsed, keys

def split_by_ext_property(parsed, ext_property):
    assert len(parsed)==len(ext_property)
    keys_list = sorted(list(set(ext_property)))
    parsed_split = [[p for p,l in zip(parsed, ext_property) if l==n] for n in keys_list]
    return parsed_split, keys_list

def split_by_property(parsed, key):
    keys_parsed = np.array([ p[2][key] for p in parsed ])
    return split_by_ext_property(parsed, keys_parsed)

def split_by_ncpus(parsed):
    ''' split by ncpus = numranks * numthreads '''
    ncpus_parsed = np.array([ int(p[2]['nr']) * int(p[2]['nt']) for p in parsed])
    return split_by_ext_property(parsed, ncpus_parsed)

def split_by_trials(parsed):
    ''' if no tr property, default to tr=0 '''
    has_tr = np.array(["tr" in p[2] for p in parsed])
    if np.any(has_tr):
        assert np.all(has_tr), f"All files must have the \"tr\" property: {get_files(np.array(parsed)[np.logical_not(has_tr)])}"
        return split_by_property(parsed, "tr")
    else:
        return [parsed], [0]

def get_files(parsed):
    return [ p[0] for p in parsed]

def get_bases(parsed):
    return [p[1] for p in parsed]

def get_properties(parsed):
    return [p[2] for p in parsed]

def get_extensions(parsed):
    return [p[3] for p in parsed]

##################################################################################################
### Parsing Multiple Output Directories

def get_dirs():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dirs", nargs="+", default=".")
    args, _ = parser.parse_known_args()

    abspaths = [str(Path(d).resolve(strict=True)) for d in args.dirs]

    print("dirs:", flush=True)
    for i,d in enumerate(abspaths):
        print(f"{i+1:5}. {d}", flush=True)
    print("")

    return abspaths

##################################################################################################
### Processing Output Files

def process_time_df(df, lj=False, bonded=False, comm_force=False, return_run=False):
    # remove Run
    df_Run = df["Run"]
    df = df.drop(columns="Run")

    # optionally remove FENE and Angle
    if lj:
        df = df.drop(columns="FENE")
        df = df.drop(columns="Angle")

    # Combine Comm1 and Comm2
    df["Comm1"] += np.array(df["Comm2"])
    df = df.drop(columns="Comm2")
    df = df.rename(columns={"Comm1":"Comm"})

    # Optionally, combine FENE and Angle
    if bonded:
        if not lj:
            df["FENE"] += np.array(df["Angle"])
            df = df.drop(columns="Angle")
            df = df.rename(columns={"FENE":"Bonded\nForces"})
        df = df.rename(columns={"Pair":"Non-bonded\nForces"})

    # Optionally combine Comm1 + Comm2 + Force
    if comm_force:
        assert not bonded
        if not lj:
            df["Pair"] += np.array(df["FENE"])
            df["Pair"] += np.array(df["Angle"])
            df = df.drop(columns="FENE")
            df = df.drop(columns="Angle")
        df["Pair"] += np.array(df["Comm"])
        df = df.drop(columns="Comm")
        df = df.rename(columns={"Pair":"Force+Comm"})

    # Combine Int1 and Int2
    df["Int1"] += np.array(df["Int2"])
    df = df.drop(columns="Int2")
    df = df.rename(columns={"Int1":"Integrate"})

    # Subtract Resort by Rebuild
    df["Resort"] -= np.array(df["Rebuild"])
    df = df.rename(columns={"Rebuild":"Neigh"})

    # Move NeighList before Rebuild
    # and move Other to end
    df_Resort = df["Resort"]
    df_Other = df["Other"]
    df = df.drop(columns="Resort")
    df = df.drop(columns="Other")

    df = pd.concat([df, df_Resort], axis=1)
    df = pd.concat([df, df_Other], axis=1)

    if return_run:
        return df, pd.DataFrame(df_Run)
    else:
        return df

# max, min, avg, stderr
def get_trial_stats(df_trials):
    ops = {
        "mean" : lambda x: x.mean(),
        "min" : lambda x: x.min(),
        "max" : lambda x: x.max(),
        "sem" : lambda x: x.sem(ddof=0),
        "std" : lambda x: x.std(ddof=0)
    }

    df_op = {}
    for op in ops:
        df_stack = pd.concat([df.stack() if isinstance(df, pd.DataFrame) else df for df in df_trials],axis=1)
        df_stack_op = df_stack.apply(ops[op], axis=1)
        df_op[op] = df_stack_op.unstack() if isinstance(df_stack_op.index, pd.MultiIndex) else df_stack_op

    # dirty hack to get asymmetric error bars (NOTE: uses transpose)
    if isinstance(df_op["mean"], pd.DataFrame):
        df_op["min_max"] = [
            [df_op["mean"][c] - df_op["min"][c], df_op["max"][c] - df_op["mean"][c]]
            for c in df_op["mean"].columns]
    else:
        df_op["min_max"] = [
            [df_op["mean"] - df_op["min"], df_op["max"] - df_op["mean"]]]

    df_op["num"] = len(df_trials)

    return df_op

def process_time_df_key(parsed, rt, key, lj, **kwargs):
    ''' process a group of dfs of one runtype by integer key '''
    filtered = filter_property(parsed, "data", "t")
    filtered = filter_property(filtered, "rt", rt)

    # sort by key
    filtered, props_list = sort_by_property(filtered, key)

    filenames = [r[0] for r in filtered]
    dfs = [pd.read_pickle(f).T.rename(index={rt:n}) \
        for f,n in zip(filenames, props_list)]
    df = pd.concat(dfs, axis=0)
    df = df.rename_axis("MPI Ranks", axis=0)
    df = df.rename_axis("Section", axis=1)

    return process_time_df(df, lj=lj, return_run=True, **kwargs)

def process_time_df_rts_key(parsed, rts, key, lj, **kwargs):
    ''' group parsed into multiple dfs by run type and process by key'''
    df_runs = []
    df_secs = []
    for rt in rts:
        df_sec, df_run = process_time_df_key(parsed, rt, key, lj, **kwargs)
        df_secs.append(df_sec)
        df_runs.append(df_run)
    return df_runs, df_secs

def process_time_df_rts_nr(parsed, rts, lj):
    ''' group parsed into multiple dfs by run type and process by rank (for strong scaling) '''
    return process_time_df_rts_key(parsed, rts, "nr", lj, **kwargs)

def all_to_efficiency(df, baseline_idx=0):
    ''' convert time df into efficiency df '''
    baseline_idx = 0
    t_base = df.iloc[baseline_idx]
    df_eff = t_base / df
    df_eff = df_eff.div(df.index, axis=0)
    return df_eff

##################################################################################################

def print_arguments(args):
    argMaxLen = max([len(arg) for arg in vars(args)])
    print("ARGUMENTS", flush=True)
    for arg in vars(args):
        print_variable(arg, getattr(args, arg), argMaxLen)
    print("")

def print_output_names(out_file):
    argMaxLen = max([len(arg) for arg in out_file])
    print("OUTPUT", flush=True)
    for output in out_file:
        print_variable(output, out_file[output], argMaxLen)
    print("")

##################################################################################################
# Useful data types

class FixedDict(object):
    def __init__(self, dictionary):
        self._dictionary = dictionary
    def __setitem__(self, key, item):
            if key not in self._dictionary:
                raise KeyError("The key {} is not defined.".format(key))
            self._dictionary[key] = item
    def __getitem__(self, key):
        return self._dictionary[key]
