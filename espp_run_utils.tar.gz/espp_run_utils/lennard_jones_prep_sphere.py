import numpy as np
from .utils import Timer, print_variable

from .lennard_jones_prep import *

def filter(x, y, z, c):
        return x[c], y[c], z[c]

def filter_in_sphere(x, y, z, center, radius):
    return ((x-center[0])**2 + (y-center[1])**2 + (z-center[2])**2) < (radius**2)

def prep_sphere(particles_per_direction = 32,
                repl = (8,8,8),
                inSphere = False,
                densityFactor = 0.0,
                sphereSkin = 0.1,
                radiusFactor = 0.7,
                velocities = True
                ):

    print("\nprep_sphere")
    outputNames = ["particles_per_direction", "repl", "inSphere", "densityFactor", "sphereSkin", "radiusFactor"]
    argMaxLen = max([len(arg) for arg in outputNames])
    for output in outputNames:
        print_variable(output, locals()[output], argMaxLen)
    print("")

    T = Timer("generating particles 1")
    x, y, z, Lx, Ly, Lz, vx, vy, vz = generate_and_replicate_particles(particles_per_direction, repl, velocities=velocities)
    T.end()

    num_particles_full = len(x)
    size_full = (Lx, Ly, Lz)

    center = (Lx/2., Ly/2., Lz/2.)
    radius = min((Lx/2., Ly/2., Lz/2.)) * radiusFactor # midline radius

    # apply sphereSkin so particles don't collide
    radius1 = radius * ((1. - sphereSkin/2.) if inSphere else (1. + sphereSkin/2.))
    radius2 = radius * ((1. + sphereSkin/2.) if inSphere else (1. - sphereSkin/2.))

    vol_rate = 4./3.*np.pi*radius1**3 / np.prod(size_full)

    print_variable("inSphere", inSphere, obey_quiet=True)

    T = Timer("filtering particles 1")
    bool_in_sphere = filter_in_sphere(x, y, z, center, radius1)
    condition = bool_in_sphere if inSphere else np.logical_not(bool_in_sphere)
    x, y, z = filter(x, y, z, condition)
    if velocities:
        vx, vy, vz = filter(vx, vy, vz, condition)
    T.end()

    num_in = bool_in_sphere.sum()
    num_rate = num_in / num_particles_full

    print_variable("1 num_in", num_in, obey_quiet=True)
    print_variable("1 vol_rate", vol_rate, obey_quiet=True)
    print_variable("1 num_rate", num_rate, obey_quiet=True)

    if densityFactor > 0:
        rho2 = RHO_DEFAULT * densityFactor
        particles_per_direction2 = int(densityFactor**(1./3.) * particles_per_direction) + 1

        T = Timer("generating particles 2")
        x2, y2, z2, Lx2, Ly2, Lz2, vx2, vy2, vz2 = generate_and_replicate_particles(particles_per_direction2, repl, rho2, velocities=velocities)
        T.end()

        T = Timer("filtering particles 2")
        in_box = (x2 < Lx) & (y2 < Ly) & (z2 < Lz)
        bool_in_sphere = filter_in_sphere(x2, y2, z2, center, radius2)
        condition = (bool_in_sphere if not inSphere else np.logical_not(bool_in_sphere)) & in_box
        x2, y2, z2 = filter(x2, y2, z2, condition)
        if velocities:
            vx2, vy2, vz2 = filter(vx2, vy2, vz2, condition)
        T.end()

        out_of_box_rate = np.logical_not(in_box).sum() / len(x2)
        print_variable("2 out_of_box_rate", out_of_box_rate, obey_quiet=True)

        num_in = bool_in_sphere.sum()
        num_rate = num_in / in_box.sum()
        vol_rate = 4./3. * np.pi * radius2**3 / np.prod(size_full)

        print_variable("2 num_in", num_in, obey_quiet=True)
        print_variable("2 vol_rate", vol_rate, obey_quiet=True)
        print_variable("2 num_rate", num_rate, obey_quiet=True)

        T = Timer("combining particles")
        x = np.concatenate([x, x2])
        y = np.concatenate([y, y2])
        z = np.concatenate([z, z2])
        if velocities:
            vx = np.concatenate([vx, vx2])
            vy = np.concatenate([vy, vy2])
            vz = np.concatenate([vz, vz2])
        T.end()

    return x, y, z, Lx, Ly, Lz, vx, vy, vz
