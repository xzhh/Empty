from . import lattice, velocities
from .utils import Timer, print_variable

import numpy as np

RHO_DEFAULT = 0.8442

def generate_particles(particles_per_direction, rho=RHO_DEFAULT, velocities=True):
    x, y, z, Lx, Ly, Lz = generate_positions(particles_per_direction, rho)
    if velocities:
        num_particles = len(x)
        vx, vy, vz = generate_velocities(num_particles)
    else:
        vx = vy = vz = None
    return x, y, z, Lx, Ly, Lz, vx, vy, vz

def generate_positions(particles_per_direction, rho=RHO_DEFAULT, perfect=True):
    num_particles = particles_per_direction**3
    x, y, z, Lx, Ly, Lz = lattice.createCubic(num_particles, rho=rho, perfect=perfect)
    return x, y, z, Lx, Ly, Lz

def generate_velocities(num_particles, T=0.6):
    vx, vy, vz = velocities.gaussian(T=T, N=num_particles, zero_momentum=True)
    return vx, vy, vz

def preReplicate(num_particles_orig, Lx_orig, Ly_orig, Lz_orig, xdim=1, ydim=1, zdim=1):
    tot_repl = xdim * ydim * zdim
    num_particles = num_particles_orig * tot_repl
    Lx = Lx_orig * xdim
    Ly = Ly_orig * ydim
    Lz = Lz_orig * zdim
    return num_particles, Lx, Ly, Lz

def replicate_positions(x, y, z, Lx, Ly, Lz, x_dim=1, y_dim=1, z_dim=1):
    old_size = len(x)
    tot_repl = x_dim * y_dim * z_dim
    new_size = old_size * tot_repl

    x_replicated = np.tile(x, tot_repl)
    y_replicated = np.tile(y, tot_repl)
    z_replicated = np.tile(z, tot_repl)

    for i in range(x_dim):
        for j in range(y_dim):
            for k in range(z_dim):
                shift_start = old_size * ( k + z_dim * ( j + y_dim * i ) )
                shift_end = shift_start + old_size

                x_replicated[shift_start:shift_end] += i * Lx
                y_replicated[shift_start:shift_end] += j * Ly
                z_replicated[shift_start:shift_end] += k * Lz

    # modify the box size
    Lx_replicated = x_dim * Lx
    Ly_replicated = y_dim * Ly
    Lz_replicated = z_dim * Lz

    return x_replicated, y_replicated, z_replicated, Lx_replicated, Ly_replicated, Lz_replicated

def replicate_velocities(vx, vy, vz, x_dim=1, y_dim=1, z_dim=1):
    if (vx is None) or (vy is None) or (vz is None):
        return None, None, None
    tot_repl = x_dim * y_dim * z_dim
    vx_repl  = np.tile(vx, tot_repl)
    vy_repl  = np.tile(vy, tot_repl)
    vz_repl  = np.tile(vz, tot_repl)
    return vx_repl, vy_repl, vz_repl

def generate_and_replicate_particles(particles_per_direction, repl, rho=RHO_DEFAULT, velocities=True):
    x, y, z, Lx, Ly, Lz, vx, vy, vz = generate_particles(particles_per_direction, rho=rho, velocities=velocities)

    num_particles_seed = len(x)
    size_seed = (Lx, Ly, Lz)
    print_variable("num_particles_seed", num_particles_seed, obey_quiet=True)
    print_variable("size_seed", size_seed, obey_quiet=True)

    x, y, z, Lx, Ly, Lz = replicate_positions(x, y, z, Lx, Ly, Lz, *repl)
    vx, vy, vz = replicate_velocities(vx, vy, vz, *repl)

    num_particles_full = len(x)
    size_full = (Lx, Ly, Lz)
    print_variable("num_particles_full", num_particles_full, obey_quiet=True)
    print_variable("size_full", size_full, obey_quiet=True)

    return x, y, z, Lx, Ly, Lz, vx, vy, vz

def bin_and_save_2d(x, y, Lx, Ly, x_bins, y_bins, filename):
    T = Timer("binning and saving particle positions")
    H, xe, ye = np.histogram2d(x,y,bins=[x_bins,y_bins],range=[[0,Lx],[0,Ly]])
    np.save(filename, H)
    print("Saving to", filename)
    T.end()
