import argparse
import os
import json
from pathlib import Path
from types import MappingProxyType

machine_meta = MappingProxyType({
    "mogon": {
        "machine":"mogon",
        "cores_per_socket":16,
        "label":"Mogon (Intel Skylake)",
        "shortlabel":"Mogon",
        "vectorwidth" : 8
    },
    "amd": {
        "machine":"amd",
        "cores_per_socket":32,
        "label":"AMD EPYC Rome",
        "shortlabel":"AMD",
        "vectorwidth" : 4
    },
    "raven": {
        "machine":"raven",
        "cores_per_socket":36,
        "label":"Raven (Intel Icelake)",
        "shortlabel":"Raven",
        "vectorwidth" : 8
    },
})

# name format for cwd: *-MACHINE
def get_meta_from_cwd():
    cwd = os.getcwd()
    key = cwd.split(os.path.sep)[-1].split("-")[-1]
    if not key in machine_meta:
        raise KeyError(f"key={key} derived from cwd={cwd} not found in machine_meta dict")
    return machine_meta[key]

def get_meta_file():
    parser = argparse.ArgumentParser()
    parser.add_argument("--meta", type=str, default="meta.json")
    args, _ = parser.parse_known_args()

    if not os.path.exists(args.meta):
        raise FileNotFoundError(f"Meta file {args.meta} does not exist in {os.getcwd()}")

    return args.meta

def read_meta_file(filename=None):
    if filename is None:
        filename = get_meta_file()
    with open(filename, "r") as meta_file:
        return MappingProxyType(json.load(meta_file))

def write_meta_file_machines(backup=False):
    ls = os.listdir()
    ls = [l for l in ls if l.startswith("res-")]
    mn = [l.split("-")[-1] for l in ls]
    for l,m in zip(ls,mn):
        p = Path(l) / "meta.json"
        mf = machine_meta[m]
        json_object = json.dumps(mf, indent=4)
        with open(p, "w") as meta_file:
            meta_file.write(json_object)
            meta_file.write("")
