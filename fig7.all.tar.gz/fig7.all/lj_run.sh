source ../../machine_variables.sh

DATEF=$(date "+%Y-%m-%d--%H-%M-%S-%N")
echo DATEF=${DATEF}
OUT_BASE="${0##*/}-${DATEF}"
echo OUT_BASE=${OUT_BASE}
SECONDS=0

###################################################################################################

NUM_TRIALS=1

echo '================================================================================'
SOURCE_ME=${ESPP_HPX_SOURCE_DIR}
echo SOURCE_ME=$SOURCE_ME
source $SOURCE_ME
ESPP_EVAL_DIR="${WORKFLOW_TOP_DIR}/evaluation"
export PYTHONPATH="${PYTHONPATH}:${ESPP_EVAL_DIR}"
echo '--------------------------------------------------------------------------------'

CMD_PRE="srun --nodes=1 ${SRUN_OPTIONS}"
SIM_ARGS=""
OUT_ARGS="--outBase ${OUT_BASE}"

CMD_SLURM_PRE_MPI="--ntasks-per-node=$MPI_TASKS_PER_NODE --cpus-per-task=$MPI_CPUS_PER_TASK"
CMD_SLURM_PRE_HPX="--ntasks-per-node=$HPX_TASKS_PER_NODE --cpus-per-task=$HPX_CPUS_PER_TASK"

###################################################################################################

function run_cmd() {
    EXE_ARGS="--runType ${RUN_TYPE} --numSubs=${NUM_SUBS} --hpx:threads=${NUM_THREADS}  --trial ${TRIAL}"
    EXE_ARGS="${EXE_ARGS} --HPX4ESPP_OPTIMIZE_COMM ${HPX4ESPP_OPTIMIZE_COMM}"
    CMD="${CMD_PRE} -n ${NUM_RANKS} ${CMD_SLURM_PRE} python lj.py ${SIM_ARGS} ${EXE_ARGS} ${OUT_ARGS}"
    [[ ! -z "$JEMALLOC_ROOT" ]] && CMD="LD_PRELOAD=${JEMALLOC_ROOT}/lib/libjemalloc.so ${CMD}"
    echo CMD=\"${CMD}\"
    echo
    eval $CMD
    echo
    echo '--------------------------------------------------------------------------------'
}

function run_with_num_ranks() {
    ###############################################################################################
    ### hpx_off
    RUN_TYPE="hpx_off"
    NUM_RANKS=${NUM_RANKS_MPI}
    CMD_SLURM_PRE=${CMD_SLURM_PRE_MPI}
    NUM_THREADS=1
    NUM_SUBS=1

    HPX4ESPP_OPTIMIZE_COMM=0

    run_cmd

    ###############################################################################################
    ### hpx_on
    RUN_TYPE="hpx_on"
    NUM_RANKS=${NUM_RANKS_HPX}
    CMD_SLURM_PRE=${CMD_SLURM_PRE_HPX}
    NUM_THREADS=${HPX_NUM_THREADS}

    HPX4ESPP_OPTIMIZE_COMM=1

    for NUM_SUBS in ${NUM_SUBS_LIST[@]}
    do
        run_cmd
    done
}

function run_single_trial() {
    ###############################################################################################
    ## single socket
    NUM_RANKS_MPI=${MPI_TASKS_PER_SOCKET}
    NUM_RANKS_HPX=1
    NUM_SUBS_LIST="${BULK_NUM_SUBS_LIST_SOCKET[@]}"

    run_with_num_ranks

    ###############################################################################################
    ## single node (2 sockets)
    NUM_RANKS_MPI=${MPI_TASKS_PER_NODE}
    NUM_RANKS_HPX=2
    NUM_SUBS_LIST="${BULK_NUM_SUBS_LIST_NODE[@]}"

    run_with_num_ranks

    ###############################################################################################
}

for (( TRIAL = 0; TRIAL < $NUM_TRIALS; TRIAL++ ))
do
    echo '================================================================================'
    echo
    echo TRIAL=${TRIAL}
    echo
    run_single_trial
    echo
done
###################################################################################################

echo
echo '================================================================================'
echo
echo SECONDS=$SECONDS
echo
