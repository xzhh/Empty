import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
from pprint import pprint

import espp_run_utils.utils as ut
import espp_run_utils.plotting as pl
import espp_run_utils.meta as meta

FIG_BASE = "fig-mpi-vs-hpx-bulk-lj"

figsize = [i for i in plt.rcParams["figure.figsize"]]
figsize = [figsize[0]*0.66,figsize[1]*0.8]
plt.rcParams["figure.figsize"] = figsize

def main(working_dir):
    os.chdir(working_dir)
    print("="*100)
    print(f"\ndir: {os.getcwd()}")

    meta_vars = meta.get_meta_from_cwd()
    filename_suffix = "-"+meta_vars["machine"]

    base = ut.get_filename_base()
    files = ut.get_files_from_base(base)
    parsed = ut.parse_files(files)

    parsed_split, ncpus_list = ut.split_by_ncpus(parsed)

    cores_per_socket = meta_vars["cores_per_socket"]
    for p_ncpus, ncpus in zip(parsed_split, ncpus_list):
        nsockets = ncpus//cores_per_socket
        filename_prefix = f"{FIG_BASE}-nsock-{nsockets}" + filename_suffix
        pl.plot_ns_tuning(p_ncpus, f"num sockets = {nsockets}", filename_prefix, print_info=True)

if __name__ == "__main__":
    dirs = ut.get_dirs()
    for working_dir in dirs:
        main(working_dir)
