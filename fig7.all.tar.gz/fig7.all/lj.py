#!/usr/bin/env python3
#  Copyright (C) 2021
#      Max Planck Institute for Polymer Research & JGU Mainz
#  This file is part of ESPResSo++.
#
#  ESPResSo++ is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  ESPResSo++ is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.

###########################################################################
#                                                                         #
#  ESPResSo++ Python script for a Lennard-Jones System including          #
#  runtime details
#                                                                         #
###########################################################################

import time
import espressopp
import argparse
import numpy as np
import sys
from mpi4py import MPI

import espp_run_utils.utils as ut
import espp_run_utils.lennard_jones_prep as lj_prep

######################################################################
print(espressopp.Version().info())
print('Setting up simulation ...\n')

simulation = "lj_bulk"

######################################################################
### Parse arguments
parser = argparse.ArgumentParser()

# simulation type

# execution parameters
parser.add_argument("--runType", type=str, choices={"orig", "vec", "hpx_off", "hpx_on"}, required=True)
parser.add_argument("--numSubs", type=int, default=1)

# output parameters
parser.add_argument("--outBase", type=str, required=True)
parser.add_argument("--trial", type=int, default=0, required=True)

# external parameters (hpx)
parser.add_argument("--hpx:threads", dest="hpxThreads")

args, _ = parser.parse_known_args()

ut.print_arguments(args)
######################################################################

######################################################################
### output filenames
props_sim = {
    "sim":simulation,
}
props_base = {
    "rt":args.runType,
    "nr":MPI.COMM_WORLD.Get_size(),
    "nt":args.hpxThreads,
    "ns":args.numSubs,
    "tr":args.trial,
}
out_file = {
    "time":ut.generate_filename(args.outBase, {**props_sim, "data":"t", **props_base}, "pkl"),
    "verlet_list":ut.generate_filename(args.outBase, {**props_sim, "data":"vl", **props_base}, "pkl")
}

ut.print_output_names(out_file)
######################################################################

######################################################################
### general parameters
nsteps      = 1000
timestep    = 0.005
temperature = 1.0

ppd         = 32
replicate   = (2,2,2)

######################################################################
### simulation-specific parameters
print("Running Lennard-Jones simulation")
rc          = 2.5
skin        = 0.3
epsilon     = 1.0
sigma       = 1.0

######################################################################
### setup simulation

T = ut.Timer("Generating input particles")
x, y, z, Lx, Ly, Lz = lj_prep.generate_positions(ppd)
bonds = angles = []
T.end()

T = ut.Timer("Replicating particles")
bonds, angles, x, y, z, Lx, Ly, Lz = espressopp.tools.replicate(bonds, angles, x, y, z, Lx, Ly, Lz, *replicate)
T.end()

num_particles = len(x)
density = num_particles / (Lx * Ly * Lz)
box = (Lx, Ly, Lz)

use_hpx4espp = (args.runType == "hpx_on" or args.runType == "hpx_off")
hpx_start = (args.runType == "hpx_on")
use_vec = (args.runType == "vec")
use_orig = (args.runType == "orig")

T = ut.Timer("Generating system")
if use_hpx4espp:
    import espressopp.hpx4espp
    system, integrator = espressopp.hpx4espp.standard_system.Default(numSubs=args.numSubs, box=box, rc=rc, skin=skin, dt=timestep, temperature=temperature)
elif use_vec:
    system, integrator = espressopp.vec.standard_system.Default(box=box, rc=rc, skin=skin, dt=timestep, temperature=temperature)
elif use_orig:
    system, integrator = espressopp.standard_system.Default(box=box, rc=rc, skin=skin, dt=timestep, temperature=temperature)
else:
    raise ValueError(f"Invalid args.runType={args.runType}")
T.end()

print("")

T = ut.Timer("Adding particles")
properties = ['id', 'type', 'mass', 'posx', 'posy', 'posz']
ids = np.arange(1, num_particles+1)
types = np.zeros(num_particles)
mass = np.ones(num_particles)
particles = np.stack((ids, types, mass, x, y, z), axis=-1)
system.storage.addParticlesArray(particles, *properties)
T.end()

T = ut.Timer("Decompose")
system.storage.decompose()
T.end()

# Lennard-Jones with Verlet list
if use_hpx4espp:
    vl      = espressopp.hpx4espp.VerletList(system, cutoff = rc)
    potLJ   = espressopp.hpx4espp.interaction.LennardJones(epsilon=epsilon, sigma=sigma, cutoff=rc, shift=0)
    interLJ = espressopp.hpx4espp.interaction.VerletListLennardJones(vl)
    interLJ.setPotential(type1=0, type2=0, potential=potLJ)
    system.addInteraction(interLJ)
elif use_vec:
    vl      = espressopp.vec.VerletList(system, cutoff = rc)
    potLJ   = espressopp.vec.interaction.LennardJones(epsilon=epsilon, sigma=sigma, cutoff=rc, shift=0)
    interLJ = espressopp.vec.interaction.VerletListLennardJones(vl)
    interLJ.setPotential(type1=0, type2=0, potential=potLJ)
    system.addInteraction(interLJ)
elif use_orig:
    vl      = espressopp.VerletList(system, cutoff = rc, useBuffers=False)
    potLJ   = espressopp.interaction.LennardJones(epsilon=epsilon, sigma=sigma, cutoff=rc, shift=0)
    interLJ = espressopp.interaction.VerletListLennardJones(vl)
    interLJ.setPotential(type1=0, type2=0, potential=potLJ)
    system.addInteraction(interLJ)

# print simulation parameters
print('')
print('number of particles = ', num_particles)
print('box                 = ', box)
print('density             = ', density)
print('rc                  = ', rc)
print('dt                  = ', integrator.dt)
print('skin                = ', system.skin)
print('temperature         = ', temperature)
print('nsteps              = ', nsteps)
print('NodeGrid            = ', system.storage.getNodeGrid())
print('CellGrid            = ', system.storage.getCellGrid())
print('')
print('use_hpx4espp        = ', use_hpx4espp)
print('hpx_start           = ', hpx_start)
print('use_vec             = ', use_vec)
print('use_orig            = ', use_orig)
print('')
######################################################################
### run simulation

vl.resetTimers()
espressopp.tools.analyse.info(system, integrator)

if use_hpx4espp:
    hpx = espressopp.hpx4espp.HPXRuntime()

if hpx_start:
    hpx.start()

start_time = time.process_time()
integrator.run(nsteps)
end_time = time.process_time()

if hpx_start:
    hpx.stop()

espressopp.tools.analyse.info(system, integrator)
espressopp.tools.analyse.final_info(system, integrator, vl, start_time, end_time)

######################################################################
### export timers

def calc_timers(alltimers, labels):
    t = []
    nprocs = len(alltimers)
    for ntimer in range(len(labels)):
        t.append(0.0)
        for k in range(nprocs):
            t[ntimer] += alltimers[k][ntimer]
        t[ntimer] /= nprocs
    return t

def show_timers(alltimers, labels, precision=3):
    import sys
    fmt1 = '%.' + str(precision) + 'f\n'
    fmt2 = '%.' + str(precision) + 'f (%.' + str(precision) + 'f)\n'
    t = calc_timers(alltimers, labels)
    for i,label in enumerate(labels):
        sys.stdout.write('{:20} time = '.format(label) + fmt1 % t[i])

def save_timers(filename, runType, alltimers, labels, precision=3, show_df=False):
    import pandas as pd
    t = calc_timers(alltimers, labels)
    df = pd.DataFrame(data=t,index=labels, columns=[runType])
    if show_df: print(df)
    print("Saving to", filename)
    df.to_pickle(filename)

labels = ["Run","Pair","FENE","Angle","Comm1","Comm2","Int1","Int2","Resort","Other","Rebuild"]
alltimers = [a+b  for a,b in zip(integrator.getTimers(), vl.getTimers())]

assert args.runType is not None
save_timers(out_file["time"], args.runType, alltimers, labels)
