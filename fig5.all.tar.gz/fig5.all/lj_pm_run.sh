source ../../machine_variables.sh

DATEF=$(date "+%Y-%m-%d--%H-%M-%S-%N")
echo DATEF=${DATEF}
OUT_BASE="${0##*/}-${DATEF}"
echo OUT_BASE=${OUT_BASE}
SECONDS=0

###################################################################################################

NUM_TRIALS=3

CMD_PRE="srun --nodes=1 ${SRUN_OPTIONS}"
CMD_MPI_PRE="--ntasks-per-node=$MPI_TASKS_PER_NODE --cpus-per-task=$MPI_CPUS_PER_TASK"

OUT_ARGS="--outBase ${OUT_BASE}"

RUN_TYPE_LIST=("orig" "soa" "vec")
SOURCES_LIST=(${ESPP_HPX_SOURCE_DIR} ${ESPP_HPX_NO_VEC_SOURCE_DIR} ${ESPP_HPX_SOURCE_DIR})

SIM_TYPE_LIST=("lj" "pm")

###################################################################################################

function run_cmd() {
    CMD="${CMD_PRE} -n ${MPI_NP} ${CMD_MPI_PRE} python lj_pm.py ${SIM_ARGS} ${EXE_ARGS} ${OUT_ARGS}"
    [[ ! -z "$JEMALLOC_ROOT" ]] && CMD="LD_PRELOAD=${JEMALLOC_ROOT}/lib/libjemalloc.so ${CMD}"
    echo CMD=\"${CMD}\"
    echo
    eval $CMD
    echo
    echo '--------------------------------------------------------------------------------'
}

###################################################################################################

for (( TRIAL = 0; TRIAL < $NUM_TRIALS; TRIAL++ ))
do
    echo '================================================================================'
    echo
    echo TRIAL=${TRIAL}
    echo
    for (( I_RUN_TYPE = 0; I_RUN_TYPE < ${#RUN_TYPE_LIST[@]}; I_RUN_TYPE++ ))
    do
        RUN_TYPE=${RUN_TYPE_LIST[$I_RUN_TYPE]}
        EXE_ARGS="--runType ${RUN_TYPE} --trial ${TRIAL}"

        echo '================================================================================'
        echo
        echo RUN_TYPE=${RUN_TYPE}
        echo
        SOURCE_ME=${SOURCES_LIST[$I_RUN_TYPE]}
        echo SOURCE_ME=${SOURCE_ME}
        echo
        source ${SOURCE_ME}
        export PYTHONPATH="${PYTHONPATH}:${ESPP_EVAL_DIR}"
        echo '================================================================================'

        for SIM_TYPE in "${SIM_TYPE_LIST[@]}";
        do
            SIM_ARGS="--simulation ${SIM_TYPE}"

            for MPI_NP in "${MPI_NP_LIST[@]}";
            do
                run_cmd
            done
        done
    done
done
###################################################################################################

echo
echo '================================================================================'
echo
echo SECONDS=$SECONDS
echo

