import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
import os, sys
from pprint import pprint

import matplotlib.pyplot as plt

import espp_run_utils.utils as ut
import espp_run_utils.plotting as pl
import espp_run_utils.meta as meta

figsize = [i for i in plt.rcParams["figure.figsize"]]
figsize_strong = [figsize[0]*0.6,figsize[1]*0.75]
figsize_combined = [figsize[0]*0.6,figsize[1]]
ut.printv("figsize_strong",figsize_strong)
ut.printv("figsize_combined",figsize_combined)

RUN_TIME = "elapsed time (s)"
PC_RUN_TIME = "% of total runtime"
SECTION = "section"
RUN_TYPE = "run type"
SPEEDUP = "speedup"
PAR_EFF = "parallel efficiency"
MPI_RANKS = "MPI ranks"

RTS = ["orig", "soa", "vec"]
RTS_TEXT = ["ORIG", "SOA", "VEC"]
TEXT_PROP = {'size':'x-small'}

MARKERS = ["o", "v", "s"]
LINESTYLES = ["dotted", "dashdot", "dashed"]
COLORS = ["grey"] + sns.color_palette("magma", n_colors=3)

FIG_BASE = "fig-soa-vec"

def format_lines(ax, markers=MARKERS, linestyles=LINESTYLES, colors=COLORS):
    for i, line in enumerate(ax.get_lines()):
        line.set_marker(markers[i])
        line.set_linestyle(linestyles[i])
        line.set_color(colors[i])
    return ax

def format_lines_slice(ax, start=None, stop=None):
    return format_lines(ax, markers=MARKERS[start:stop], linestyles=LINESTYLES[start:stop], colors=COLORS[start:stop])

def format_log_scale(ax):
    ax.set_xscale("log", base=2)
    pl.scalar_formatter(ax)
    pl.integer_formatter(ax,x=True)
    return ax

def df_secs_stats_get_breakdown(df_secs_stats):
    df_secs = df_secs_stats["mean"]
    ranks = sorted(list(set(df_secs.index.get_level_values(0))))
    secs = list(df_secs.index.get_level_values(1))
    secs = secs[:len(secs)//len(ranks)]
    return df_secs, ranks, secs

def parse_timings(parsed, lj=True):
    # strong scaling for total runtime
    filtered = ut.filter_property(parsed, "data", "t")
    filename_base = ut.generate_filename_replace_props(filtered[0], {"nr":"ZZ","rt":"ZZ","tr":"ZZ"})
    p_sim, k_sim = ut.split_by_property(filtered, "sim")
    assert len(k_sim)==1, f"plot_timings should process only one sim type. k_sim={k_sim}"
    sim = k_sim[0]

    filtered_trials, trials = ut.split_by_trials(filtered)

    df_runs_stats = []
    df_secs_stats = []
    for ft, t in zip(filtered_trials, trials):
        df_runs, df_secs = ut.process_time_df_rts_key(ft, RTS, "nr", lj)

        df_runs = pd.concat([d.rename(columns={"Run":rt}) for d,rt in zip(df_runs, RTS)], axis=1)
        df_runs = df_runs.rename_axis(RUN_TYPE, axis=1)
        df_runs_stats.append(df_runs)

        df_secs = pd.concat({rt:d.stack() for d,rt in zip(df_secs, RTS)}, axis=1, names=[RUN_TYPE])
        df_secs.index.set_names(SECTION, level=1, inplace=True)
        df_secs_stats.append(df_secs)

    df_runs_stats = ut.get_trial_stats(df_runs_stats)
    df_secs_stats = ut.get_trial_stats(df_secs_stats)

    return df_runs_stats, df_secs_stats, filename_base, sim

def plot_timings(df_runs_stats, df_secs_stats, filename_base, sim, title, fig_suffix):

    pl.sns_reset()

    ###########################################################
    # compute speedup relative to orig
    df_time = df_runs_stats["mean"]
    df_orig = df_time["orig"]
    df_speedup = df_time.drop(columns="orig")
    for col in df_speedup.columns:
        df_speedup[col] = df_orig / df_speedup[col]

    print("")
    print(title)
    ut.pprint_variable("df_time", df_time, None)
    ut.pprint_variable("df_speedup", df_speedup, None)

    df_speedup_2 = df_speedup.copy()
    for col in df_speedup_2.columns: df_speedup_2.rename(columns={col:"orig->"+col}, inplace=True)
    df_speedup_2["soa->vec"] = df_time["soa"] / df_time["vec"]
    ut.pprint_variable("df_speedup_2", df_speedup_2, None)

    def plot_run_time(df, ax):
        ax = df.plot(ax=ax, ylabel=RUN_TIME, title=title)
        ax.set_yscale("log", base=10)
        ax = format_lines(ax)
        ax = format_log_scale(ax)
        # ax.grid(visible=True, which="major")
        ax.legend(RTS_TEXT, loc=0, prop=TEXT_PROP)
        return ax

    def plot_speedup(df, ax):
        ax = df.plot(ax=ax, ylabel=SPEEDUP)
        ax = format_lines_slice(ax, start=1)
        ax = format_log_scale(ax)
        ax.get_legend().remove()
        b,t = ax.get_ylim()
        # yl_factor = 0.5
        # b_new = b-(t-b)*yl_factor
        # t_new = t+(t-b)*yl_factor
        b_new = 1.0
        t_new = np.ceil(t/0.5)*0.5
        ax.set_ylim(b_new, t_new)

        return ax

    ###########################################################
    # plot runtime and speedup separately in a shared x-axis
    fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True)
    ax0 = plot_run_time(df_time, ax0)
    # ax0.get_xaxis().set_minor_locator(mpl.ticker.AutoMinorLocator(n=5))
    ax0.grid(visible=True, which="minor", linestyle="dotted" )
    ax1 = plot_speedup(df_speedup, ax1)
    ax1.get_yaxis().set_minor_locator(mpl.ticker.AutoMinorLocator())
    ax1.grid(visible=True, which="minor", linestyle="dotted" )

    pl.plot_save([filename_base + "-run-speedup-rows.pdf", f"{FIG_BASE}-run-speedup-{sim}{fig_suffix}.pdf"])

    ###########################################################
    # plot runtime with speedup as inset
    fig, ax = plt.subplots()

    # main plot: run time
    ax = plot_run_time(df_time, ax)

    # inset plot: speedup
    left, bottom, width, height = [0.34, 0.55, 0.41, 0.31]
    ax_inset = fig.add_axes([left, bottom, width, height])
    ax_inset = plot_speedup(df_speedup, ax_inset)
    inset_color = "#888"
    for spine in ax_inset.spines: ax_inset.spines[spine].set_color(inset_color)
    ax_inset.get_yaxis().set_minor_locator(mpl.ticker.AutoMinorLocator())
    ax_inset.grid(visible=True, which="major", color=inset_color, linewidth=1.0)
    ax_inset.grid(visible=True, which="minor", color=inset_color, linewidth=0.5)

    # pl.plot_save([filename_base + "-run-speedup-inset.pdf", f"{FIG_BASE}-run-speedup-{sim}-inset.pdf"])
    pl.plot_save([filename_base + "-run-speedup-inset.pdf"])

    ###########################################################
    # full parallel efficiency
    df_runs_eff = ut.all_to_efficiency(df_runs_stats["mean"])

    fig, ax = plt.subplots()
    ax = df_runs_eff.plot(ax=ax, ylabel=PAR_EFF, title=title)
    ax = format_lines(ax)
    ax = format_log_scale(ax)
    ax.grid(visible=True, which="major")
    ax.legend(loc=0)
    ax.set_ylim(0,)
    pl.plot_save(filename_base + "-eff-run.pdf")

    ###########################################################
    # time per section

    df_secs, ranks, secs = df_secs_stats_get_breakdown(df_secs_stats)

    ###########################################################
    # stacked % plot of time per section
    COLORS_PM = sns.color_palette()
    COLORS_LJ = COLORS_PM[:1] + COLORS_PM[3:]
    colors = {'lj':COLORS_LJ, 'pm':COLORS_PM}[sim]

    fig, axs = plt.subplots(ncols=len(RTS), sharey=True)

    # hack to set a single xlabel for all columns
    ax = fig.add_subplot(111, zorder=-1)
    ax.set_xlabel(MPI_RANKS, labelpad = 25)
    for spine in ax.spines: ax.spines[spine].set_visible(False)
    ax.grid(False)
    ax.tick_params(labelcolor='g', bottom=False, top=False, left=False, right=False,
                labelbottom=False, labeltop=False, labelleft=False, labelright=False,)

    for rt, ax, i in zip(RTS, axs, range(len(RTS))):
        df = pd.concat([df_secs[rt].loc[nr].rename(nr) for nr in ranks], axis=1).T
        df = df.div(df.sum(axis=1), axis=0) * 100
        ax = df.plot.bar(ax=ax, stacked=True, color=colors)
        ax.set_title(label=RTS_TEXT[i], fontdict=TEXT_PROP)

        if i < len(RTS)-1:
            ax.get_legend().remove()
        else:
            ax = pl.ax_legend_outside_box(ax, step=-1)

        ax.set_ylabel(PC_RUN_TIME)

    plt.tight_layout()
    # pl.plot_save([filename_base + "-sec.pdf", f"{FIG_BASE}-sec-percent-{sim}.pdf"])
    pl.plot_save([filename_base + "-sec.pdf"])

    ###########################################################
    # breakdown of time per section at max nr
    max_nr = max(ranks)
    df_secs_max_nr = pd.concat([df_secs[rt].loc[max_nr].rename(rt) for rt in RTS], axis=1)

    fig, ax = plt.subplots()
    ax = df_secs_max_nr.plot.bar(ax=ax, title=f"{title}, num ranks = {max_nr}", ylabel=RUN_TIME, color=COLORS)
    ax.legend(RTS_TEXT, loc=0, prop=TEXT_PROP)

    fig.tight_layout()
    # pl.plot_save([filename_base + f"-sec-nr={max_nr}.pdf", f"{FIG_BASE}-sec-time-{sim}.pdf"])
    pl.plot_save([filename_base + f"-sec-nr={max_nr}.pdf"])

def plot_combined(df_scaling_rts, titles, fig_suffix):

    num_panels = len(df_scaling_rts)

    ### -sec-time-
    fig_st, axs_st = plt.subplots(nrows=num_panels)
    sims = []

    for i, (df_scaling_rt, title) in enumerate(zip(df_scaling_rts, titles)):
        df_runs_stats, df_secs_stats, filename_base, sim = df_scaling_rt
        sims.append(sim)

        df_secs, ranks, secs = df_secs_stats_get_breakdown(df_secs_stats)

        max_nr = max(ranks)
        df_secs_max_nr = pd.concat([df_secs[rt].loc[max_nr].rename(rt) for rt in RTS], axis=1)
        axs_st[i] = df_secs_max_nr.plot.bar(ax=axs_st[i], title=f"{title}, num ranks = {max_nr}", ylabel=RUN_TIME, color=COLORS)
        axs_st[i].legend(RTS_TEXT, loc='upper right', prop=TEXT_PROP)
        axs_st[i].set_xticklabels(axs_st[i].get_xticklabels(), rotation = 45)

        if i != 0:
            axs_st[i].get_legend().remove()
        # else:
        #     axs_st[i] = pl.ax_legend_outside_box(axs_st[i], step=-1)

        df = df_secs_max_nr.copy()
        df["orig->soa"] = df["orig"] / df["soa"]
        df["orig->vec"] = df["orig"] / df["vec"]
        df["soa->vec"] = df["soa"] / df["vec"]

        print("")
        ut.print_variable("title", title, None)
        ut.pprint_variable("df", df, None)

    fig_st.tight_layout()
    pl.fig_save(fig_st, [f"{FIG_BASE}-sec-time-{'_'.join(sims)}{fig_suffix}.pdf"])

def vec_perf_model(df_scaling_rt, title, vector_width):
    df_runs_stats, df_secs_stats, filename_base, sim = df_scaling_rt
    df_secs, ranks, secs = df_secs_stats_get_breakdown(df_secs_stats)
    max_nr = max(ranks)
    df_secs_max_nr = pd.concat([df_secs[rt].loc[max_nr].rename(rt) for rt in RTS], axis=1)

    # (Pair, Neigh, rest)
    df = df_secs_max_nr.copy()
    t_Pair = df.loc["Pair"]
    t_Neigh = df.loc["Neigh"]
    t_rest = df.drop(index="Pair").drop(index="Neigh").sum(axis=0).rename("rest")
    df = pd.concat([t_Pair, t_Neigh, t_rest], axis=1)

    t_orig, t_soa, t_vec = df.sum(axis=1)
    t_soa_scaled = (df['Pair']['soa'] + df['Neigh']['soa']) / vector_width + df['rest']['soa']
    S_actual = t_soa / t_vec
    S_max    = t_soa / t_soa_scaled
    slowdown = t_vec / t_soa_scaled

    return {"S_actual": S_actual, "S_max": S_max}

def main(working_dir, make_plots=True):
    os.chdir(working_dir)
    print("="*100)
    print(f"\ndir: {os.getcwd()}")

    meta_vars = meta.get_meta_from_cwd()
    fig_suffix = "-"+meta_vars["machine"]

    base = ut.get_filename_base()
    files = ut.get_files_from_base(base)
    parsed = ut.parse_files(files)

    parsed_lj = ut.filter_property(parsed, "sim", "lj")
    parsed_pm = ut.filter_property(parsed, "sim", "pm")

    df_scaling_lj = parse_timings(parsed_lj, lj=True)
    df_scaling_pm = parse_timings(parsed_pm, lj=False)

    if make_plots:
        plt.rcParams["figure.figsize"] = figsize_strong
        plot_timings(*df_scaling_lj, title=f"Lennard-Jones ({meta_vars['shortlabel']})", fig_suffix=fig_suffix)
        plot_timings(*df_scaling_pm, title=f"Polymer Melt ({meta_vars['shortlabel']})", fig_suffix=fig_suffix)
        plt.rcParams["figure.figsize"] = figsize_combined
        plot_combined([df_scaling_lj, df_scaling_pm], ["Lennard-Jones", "Polymer Melt"], fig_suffix)

    vector_width = meta_vars["vectorwidth"]
    perf_model_lj = vec_perf_model(df_scaling_lj, "Lennard-Jones", vector_width)
    perf_model_pm = vec_perf_model(df_scaling_pm, "Polymer Melt", vector_width)

    return meta_vars["shortlabel"], perf_model_lj, perf_model_pm

if __name__ == "__main__":
    dirs = ut.get_dirs()
    perf_model_lj = {}
    perf_model_pm = {}
    for working_dir in dirs:
        machine, res_lj, res_pm = main(working_dir, make_plots=True)
        perf_model_lj[machine] = res_lj
        perf_model_pm[machine] = res_pm

    columns = lambda x: {"S_actual":f'$S^\\text{{{x}}}$',"S_max":f'$S_\\text{{max}}^\\text{{{x}}}$'}

    perf_model_lj = pd.DataFrame(perf_model_lj).T.rename(columns=columns("LJ"))
    perf_model_pm = pd.DataFrame(perf_model_pm).T.rename(columns=columns("PM"))

    print("="*100)

    df = pd.concat([perf_model_lj, perf_model_pm], axis=1)
    with pd.option_context('display.float_format', '{:0.2f}'.format, 'display.max_rows', None, 'display.max_columns', None):
        ut.pprintv("df",df,None)

    df = df.style.format(precision=2)
    print(df.to_latex(column_format='l|cc|cc',hrules=True))
